function Dashboard() {
  return (
    <div style={{ padding: '40px' }}>
      <h1>Painel Administrativo</h1>

      <h2>Financeiro</h2>
      <p>Total PIX: R$ 15.000</p>
      <p>Total Cartão: R$ 8.000</p>
      <p>Taxa administrativa: R$ 4.600</p>

      <h2>Campanhas</h2>
      <ul>
        <li>Campanha Maria - Ativa</li>
        <li>Campanha João - Em análise</li>
      </ul>
    </div>
  )
}

export default Dashboard
