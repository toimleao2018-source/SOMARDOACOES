import { Routes, Route } from 'react-router-dom'
import Home from './pages/Home'
import Dashboard from './admin/Dashboard'

function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/admin" element={<Dashboard />} />
    </Routes>
  )
}

export default App
