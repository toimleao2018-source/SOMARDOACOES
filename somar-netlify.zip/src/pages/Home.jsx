import { Heart, DollarSign } from 'lucide-react'
import { motion } from 'framer-motion'

function Home() {
  return (
    <div className="container">
      <motion.div
        className="hero"
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h1>SOMAR</h1>
        <p>Juntos Somando e compartilhando o bem</p>

        <button className="btn">
          Fazer Doação
        </button>
      </motion.div>

      <div className="cards">
        <div className="card">
          <Heart color="#7ED13B" />
          <h2>Ajude Maria</h2>
          <p>Campanha para cirurgia urgente.</p>
          <p>R$ 13.000 arrecadados via PIX</p>
        </div>

        <div className="card">
          <DollarSign color="#7ED13B" />
          <h2>Transparência</h2>
          <p>A plataforma possui taxa administrativa de 20%.</p>
        </div>
      </div>
    </div>
  )
}

export default Home
